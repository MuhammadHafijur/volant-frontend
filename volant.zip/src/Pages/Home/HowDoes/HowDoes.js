import React from "react";

const HowDoes = () => {
  return (
    <div>
      <div className="my-24">
        <h1 className="text-6xl text-center">
          How does the Volant Diffuser work?
        </h1>
      </div>
    </div>
  );
};

export default HowDoes;
